package com.example.football_scoreboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FootballScoreboardApplication {

	public static void main(String[] args) {
		SpringApplication.run(FootballScoreboardApplication.class, args);
	}

}
